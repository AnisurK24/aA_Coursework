# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)





# Bench.destroy_all

# Bench.create!(
#     description: 'bench 1',
#     lat: ,
#     lng: 
# )

# Bench.create!({"1", "37.745323", "-122.447411"}, 
# {{"1", "37.745323", "-122.447411"}, 
# {})

# Country.create(name: 'Germany', population: 81831000)
# Country.create(name: 'France', population: 65447374)



# country_list = [
#   [ "Germany", 81831000 ],
#   [ "France", 65447374 ],
#   [ "Belgium", 10839905 ],
#   [ "Netherlands", 16680000 ]
# ]

# country_list.each do |name, population|
#   Country.create( name: name, population: population )
# end

# Bench.create!(
#     description: 'bench 2',
#     lat: ,
#     lng: 
# )

# Bench.create!(
#     description: 'bench 3',
#     lat: ,
#     lng: 
# )

# Bench.create!(
#     description: 'bench 4',
#     lat: ,
#     lng: 
# )

# Bench.create!(
#     description: 'bench 5',
#     lat: ,
#     lng: 
# )