class Bench < ApplicationRecord
end
