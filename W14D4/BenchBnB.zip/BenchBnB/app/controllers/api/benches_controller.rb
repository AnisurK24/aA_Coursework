class Api::BenchesController < ApplicationController
end
